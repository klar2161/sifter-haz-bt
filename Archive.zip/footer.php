   
 <!--
   
   <div class="column-container clearfix">
			<div class="container-box">
            
        
			</div>
		

        <p>a </p>

        </div>
    -->
    


    <footer>
        <div class="footer-wrapper">
                <div class="footer-nav">
                    <?php dynamic_sidebar( 'sidebar-1' ); ?>
                </div>
                <div class="services-banner">
                    <?php dynamic_sidebar( 'sidebar-2' ); ?>
                </div>
                <div class="socials-banner">
                     <?php dynamic_sidebar( 'sidebar-3' ); ?>
                </div>
        </div>
    </footer>


<?php if(get_field('image')): ?>
        </div>
<?php endif; ?>

<?php wp_footer(); ?>

</body>
</html>