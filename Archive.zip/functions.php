<?php

function CMSprojectExam_resources() {
        wp_enqueue_style('style', get_stylesheet_uri());

}

add_action('wp_enqueue_scripts', 'CMSprojectExam_resources');

// Navigation menus
register_nav_menus(array(
    'primary' => __( 'Primary Menu' ),
    'footer' => __( 'Footer Menu' )
));

// widgets
function mytheme_widgets_init() {
    register_sidebar( array (
        'name' => __( 'Footer left', 'your-text-domain' ),
        'id' => 'sidebar-1',
        'description' => __( 'Appears on posts and pages except the optional Front Page template, which has its own widgets', 'your-text-domain' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    register_sidebar( array (
        'name' => __( 'Footer middle', 'your-text-domain' ),
        'id' => 'sidebar-2',
        'description' => __( 'Appears on posts and pages except the optional Front Page template, which has its own widgets', 'your-text-domain' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    register_sidebar( array (
        'name' => __( 'Footer right', 'your-text-domain' ),
        'id' => 'sidebar-3',
        'description' => __( 'Appears on posts and pages except the optional Front Page template, which has its own widgets', 'your-text-domain' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));

}
add_action( 'widgets_init', 'mytheme_widgets_init' );